import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/ZaraSeries/lista/master/Series/Series%20Ci%20Principal.xml'
addon = xbmcaddon.Addon('plugin.video.seriesci')