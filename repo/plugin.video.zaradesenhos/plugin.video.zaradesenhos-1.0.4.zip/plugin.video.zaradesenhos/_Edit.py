import xbmcaddon

MainBase = 'https://goo.gl/9ukptE'
addon = xbmcaddon.Addon('plugin.video.zaradesenhos')