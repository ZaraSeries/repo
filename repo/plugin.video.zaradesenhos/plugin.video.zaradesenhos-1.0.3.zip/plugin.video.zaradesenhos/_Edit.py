import xbmcaddon

MainBase = 'http://pastebin.com/raw/M8S3xjty'
addon = xbmcaddon.Addon('plugin.video.zaradesenhos')