import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/ZaraSeries/lista/master/App%20Descontinuado.xml'
addon = xbmcaddon.Addon('plugin.video.seriesci')