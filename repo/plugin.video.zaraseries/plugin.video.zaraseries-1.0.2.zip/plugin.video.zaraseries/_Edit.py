import xbmcaddon

MainBase = 'https://goo.gl/pg8IOc'
addon = xbmcaddon.Addon('plugin.video.zaraseries')