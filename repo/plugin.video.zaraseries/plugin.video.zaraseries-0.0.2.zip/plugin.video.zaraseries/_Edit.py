import xbmcaddon

MainBase = 'http://pastebin.com/raw/UrLXXipC'
addon = xbmcaddon.Addon('plugin.video.zaraseries')