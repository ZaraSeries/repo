import xbmcaddon

MainBase = 'https://goo.gl/BuUuHY'
addon = xbmcaddon.Addon('plugin.video.zaraseries')