import xbmcaddon

MainBase = 'https://goo.gl/BonBVX'
addon = xbmcaddon.Addon('plugin.video.zarafilmes')